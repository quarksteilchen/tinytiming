﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.IO.Pipes;

namespace TinyTiming
{
  public partial class Form1 : Form
  {
    string version;
    NamedPipeServerStream pipeServer = null;
    int connectedclients = 0;
    delegate void SetTextCallback(string text);
    delegate void SetTimeAddCallback(TinyTime t);
    DateTime startTime;
    string timeFormat = @"hh\:mm\:ss\,f";

    List<TinyTime> timeList;
    BindingSource b;

    public Form1()
    {
      version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();

      timeList = new List<TinyTime>();

      timeList.Add(new TinyTime(TimeSpan.Zero, TimeSource.None, "444"));

      InitializeComponent();

      startTime = DateTime.Now;
      textBoxStartTime.Text = startTime.TimeOfDay.ToString(timeFormat);
      textBoxStartTime.BackColor = Color.LightGreen;
      labelStartValid.Text = startTime.TimeOfDay.ToString(timeFormat);

      bWPipeTIMclk.RunWorkerAsync(pipeServer);

      //dGVTimes.DataSource = timeList;
      b = new BindingSource();
      b.DataSource = timeList;
      dGVTimes.DataSource = b;
      b.ResetBindings(false);

      timeList.Add(new TinyTime(TimeSpan.Zero, TimeSource.None, "666"));

      b.ResetBindings(false);
      
    }

    protected void PipeClientConnected(IAsyncResult result)
    {
      if (pipeServer != null)
        connectedclients++;
    }

    private void bWPipeTIMclk_DoWork(object sender, DoWorkEventArgs e)
    {
      NamedPipeServerStream pipeServer = (NamedPipeServerStream)e.Argument;
      pipeServer = new NamedPipeServerStream("TIMclk", PipeDirection.In);
      this.SetText("Waiting for connect...");
      pipeServer.WaitForConnection();
      this.SetText("Connected Named Pipe.");
      using (StreamReader sr = new StreamReader(pipeServer))
      {
        // Display the read text to the console
        string temp;
        while (bWPipeTIMclk.CancellationPending==false && pipeServer.IsConnected == true && (temp = sr.ReadLine()) != null)
        {
          this.SetText("RECV: "+temp);

          TinyTime t = TinyTime.Parse(temp);
          // only rising edge
          if (t.timeState != TimeState.INVALID && t.timeState == TimeState.ON)
          {
            t.internalTime = t.internalTime - startTime.TimeOfDay; // calculate runtime
            AddTime(t);
          }

          // parse time and source for a TinyTime Object
        }

        if (bWPipeTIMclk.CancellationPending == true)
        {
          e.Result = String.Empty;
          this.SetText("Cancelled");
        }
        else
        {
          // disconnected.
          this.SetText("Disconnected client.");
          e.Result = "restart";
        }
      }
    }

    private void SetText(string text)
    {
      // InvokeRequired required compares the thread ID of the
      // calling thread to the thread ID of the creating thread.
      // If these threads are different, it returns true.
      if (this.textBox1.InvokeRequired)
      {
        SetTextCallback d = new SetTextCallback(SetText);
        this.Invoke(d, new object[] { text });
      }
      else
      {
        this.textBox1.AppendText(text+"\r\n");
      }
    }

    private void bWPipeTIMclk_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
    {
      if (((string)e.Result) == "restart")
        bWPipeTIMclk.RunWorkerAsync(pipeServer);
    }

    private void Form1_FormClosing(object sender, FormClosingEventArgs e)
    {
      bWPipeTIMclk.CancelAsync();
    }

    private void timerRefresh_Tick(object sender, EventArgs e)
    {
      DateTime dt = DateTime.Now;
      this.labelSysTime.Text = dt.TimeOfDay.ToString(timeFormat);// +"," + dt.Millisecond.ToString().PadLeft(3, '0');

      TimeSpan ts = dt - startTime;

      this.labelRunTime.Text = ts.ToString(timeFormat);// +"," + dt.Millisecond.ToString().PadLeft(3, '0');
    }

    private void textBoxStartTime_TextChanged(object sender, EventArgs e)
    {
      // start time changes.
      textBoxStartTime.BackColor = Color.Yellow;
    }

    private void textBoxStartTime_Leave(object sender, EventArgs e)
    {
      KeyPressEventArgs kev = new KeyPressEventArgs((char)13);
      textBoxStartTime_KeyPress(null,kev);
    }

    private void textBoxStartTime_KeyPress(object sender, KeyPressEventArgs e)
    {
      if (e.KeyChar == (char)13)
      {
        // Enter key pressed
        // try to parse the new starttime
        try
        {
          DateTime dt = DateTime.Parse(textBoxStartTime.Text);
          this.startTime = dt;
          textBoxStartTime.BackColor = Color.LightGreen;
          labelStartValid.Text = this.startTime.TimeOfDay.ToString(timeFormat);
          //textBoxStartTime.Text = dt.ToString(timeFormat);
        }
        catch (Exception ex)
        {
          textBoxStartTime.BackColor = Color.Red;
        }
      }
    }

    /// <summary>
    /// Adds a Time to the Datagridview. Threadsafe.
    /// </summary>
    /// <param name="t"></param>
    private void AddTime(TinyTime t)
    {
      // InvokeRequired required compares the thread ID of the
      // calling thread to the thread ID of the creating thread.
      // If these threads are different, it returns true.
      if (this.dGVTimes.InvokeRequired)
      {
        SetTimeAddCallback d = new SetTimeAddCallback(AddTime);
        this.Invoke(d, new object[] { t });
      }
      else
      {
        this.timeList.Add(t);
        b.ResetBindings(false);

        // copy short time to clipboard
        if (cBcopyShortTime.Checked == true)
        {
          //Clipboard.SetText(t.ShortTime);

          if (this.ContainsFocus == false)
            SendKeys.Send(t.ShortTime);
        }
      }
    }

    /// <summary>
    /// Adds the Time of the Click as Signaltime.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void buttonSignal_Click(object sender, EventArgs e)
    {
      TinyTime t;
      t = new TinyTime(DateTime.Now.TimeOfDay - startTime.TimeOfDay, TimeSource.Manual, "");
      AddTime(t);
    }

    private void dGVTimes_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
    {
      dGVTimes.FirstDisplayedScrollingRowIndex = dGVTimes.RowCount - 1;
    }

    private void buttonToFile_Click(object sender, EventArgs e)
    {
      string file_name = "OUTPUT"+DateTime.Now.ToString("yyyy-MM-dd_HHmmss")+".txt";

      System.IO.StreamWriter objWriter;

      objWriter = new System.IO.StreamWriter(file_name);

      int count = dGVTimes.Rows.Count;

      for (int row = 0; row < count; row++)
      {
        objWriter.Write(dGVTimes.Rows[row].Cells[0].Value.ToString());
        objWriter.Write(";");
        objWriter.Write(dGVTimes.Rows[row].Cells[1].Value.ToString());
        objWriter.Write(";");
        objWriter.Write(dGVTimes.Rows[row].Cells[2].Value.ToString());
        objWriter.Write(";");
        objWriter.WriteLine(dGVTimes.Rows[row].Cells[3].Value.ToString());
      }

      objWriter.Close();
    }

  }
}
