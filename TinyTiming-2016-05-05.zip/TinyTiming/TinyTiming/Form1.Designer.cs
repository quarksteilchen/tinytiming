﻿namespace TinyTiming
{
  partial class Form1
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.bWPipeTIMclk = new System.ComponentModel.BackgroundWorker();
      this.textBox1 = new System.Windows.Forms.TextBox();
      this.labelSysTime = new System.Windows.Forms.Label();
      this.labelRunTime = new System.Windows.Forms.Label();
      this.timerRefresh = new System.Windows.Forms.Timer(this.components);
      this.textBoxStartTime = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.labelStartValid = new System.Windows.Forms.Label();
      this.dGVTimes = new System.Windows.Forms.DataGridView();
      this.dGStartNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dGTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.DGShortTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dGTimeSourceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.tinyTimeBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.buttonSignal = new System.Windows.Forms.Button();
      this.buttonToFile = new System.Windows.Forms.Button();
      this.cBcopyShortTime = new System.Windows.Forms.CheckBox();
      ((System.ComponentModel.ISupportInitialize)(this.dGVTimes)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tinyTimeBindingSource)).BeginInit();
      this.SuspendLayout();
      // 
      // bWPipeTIMclk
      // 
      this.bWPipeTIMclk.WorkerReportsProgress = true;
      this.bWPipeTIMclk.WorkerSupportsCancellation = true;
      this.bWPipeTIMclk.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bWPipeTIMclk_DoWork);
      this.bWPipeTIMclk.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bWPipeTIMclk_RunWorkerCompleted);
      // 
      // textBox1
      // 
      this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.textBox1.Location = new System.Drawing.Point(12, 299);
      this.textBox1.Multiline = true;
      this.textBox1.Name = "textBox1";
      this.textBox1.ReadOnly = true;
      this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.textBox1.Size = new System.Drawing.Size(628, 120);
      this.textBox1.TabIndex = 0;
      this.textBox1.Text = "Debug:\r\n";
      // 
      // labelSysTime
      // 
      this.labelSysTime.AutoSize = true;
      this.labelSysTime.Font = new System.Drawing.Font("Consolas", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.labelSysTime.Location = new System.Drawing.Point(12, 9);
      this.labelSysTime.Name = "labelSysTime";
      this.labelSysTime.Size = new System.Drawing.Size(175, 34);
      this.labelSysTime.TabIndex = 1;
      this.labelSysTime.Text = "SystemTime";
      // 
      // labelRunTime
      // 
      this.labelRunTime.AutoSize = true;
      this.labelRunTime.Font = new System.Drawing.Font("Consolas", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.labelRunTime.Location = new System.Drawing.Point(11, 168);
      this.labelRunTime.Name = "labelRunTime";
      this.labelRunTime.Size = new System.Drawing.Size(143, 37);
      this.labelRunTime.TabIndex = 2;
      this.labelRunTime.Text = "RunTime";
      // 
      // timerRefresh
      // 
      this.timerRefresh.Enabled = true;
      this.timerRefresh.Tick += new System.EventHandler(this.timerRefresh_Tick);
      // 
      // textBoxStartTime
      // 
      this.textBoxStartTime.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.textBoxStartTime.Location = new System.Drawing.Point(18, 90);
      this.textBoxStartTime.Name = "textBoxStartTime";
      this.textBoxStartTime.Size = new System.Drawing.Size(160, 32);
      this.textBoxStartTime.TabIndex = 3;
      this.textBoxStartTime.Text = "00:00:00,000";
      this.textBoxStartTime.TextChanged += new System.EventHandler(this.textBoxStartTime_TextChanged);
      this.textBoxStartTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxStartTime_KeyPress);
      this.textBoxStartTime.Leave += new System.EventHandler(this.textBoxStartTime_Leave);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.Location = new System.Drawing.Point(13, 62);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(110, 25);
      this.label1.TabIndex = 4;
      this.label1.Text = "Start Time";
      // 
      // labelStartValid
      // 
      this.labelStartValid.AutoSize = true;
      this.labelStartValid.Font = new System.Drawing.Font("Consolas", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.labelStartValid.Location = new System.Drawing.Point(14, 125);
      this.labelStartValid.Name = "labelStartValid";
      this.labelStartValid.Size = new System.Drawing.Size(130, 24);
      this.labelStartValid.TabIndex = 5;
      this.labelStartValid.Text = "Start Time";
      // 
      // dGVTimes
      // 
      this.dGVTimes.AllowUserToResizeRows = false;
      dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
      dataGridViewCellStyle1.NullValue = null;
      dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dGVTimes.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
      this.dGVTimes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dGVTimes.AutoGenerateColumns = false;
      this.dGVTimes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dGVTimes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dGStartNumberDataGridViewTextBoxColumn,
            this.dGTimeDataGridViewTextBoxColumn,
            this.DGShortTime,
            this.dGTimeSourceDataGridViewTextBoxColumn});
      this.dGVTimes.DataSource = this.tinyTimeBindingSource;
      this.dGVTimes.Location = new System.Drawing.Point(238, 9);
      this.dGVTimes.Name = "dGVTimes";
      this.dGVTimes.RowTemplate.DefaultCellStyle.Format = "T";
      this.dGVTimes.RowTemplate.DefaultCellStyle.NullValue = null;
      this.dGVTimes.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
      this.dGVTimes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
      this.dGVTimes.Size = new System.Drawing.Size(402, 284);
      this.dGVTimes.TabIndex = 6;
      this.dGVTimes.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dGVTimes_RowsAdded);
      // 
      // dGStartNumberDataGridViewTextBoxColumn
      // 
      this.dGStartNumberDataGridViewTextBoxColumn.DataPropertyName = "DGStartNumber";
      this.dGStartNumberDataGridViewTextBoxColumn.HeaderText = "St#";
      this.dGStartNumberDataGridViewTextBoxColumn.Name = "dGStartNumberDataGridViewTextBoxColumn";
      this.dGStartNumberDataGridViewTextBoxColumn.Width = 50;
      // 
      // dGTimeDataGridViewTextBoxColumn
      // 
      this.dGTimeDataGridViewTextBoxColumn.DataPropertyName = "DGTime";
      this.dGTimeDataGridViewTextBoxColumn.HeaderText = "Time";
      this.dGTimeDataGridViewTextBoxColumn.Name = "dGTimeDataGridViewTextBoxColumn";
      this.dGTimeDataGridViewTextBoxColumn.ReadOnly = true;
      this.dGTimeDataGridViewTextBoxColumn.Width = 120;
      // 
      // DGShortTime
      // 
      this.DGShortTime.DataPropertyName = "DGShortTime";
      this.DGShortTime.HeaderText = "DGShortTime";
      this.DGShortTime.Name = "DGShortTime";
      this.DGShortTime.ReadOnly = true;
      this.DGShortTime.Width = 50;
      // 
      // dGTimeSourceDataGridViewTextBoxColumn
      // 
      this.dGTimeSourceDataGridViewTextBoxColumn.DataPropertyName = "DGTimeSource";
      this.dGTimeSourceDataGridViewTextBoxColumn.HeaderText = "Source";
      this.dGTimeSourceDataGridViewTextBoxColumn.Name = "dGTimeSourceDataGridViewTextBoxColumn";
      this.dGTimeSourceDataGridViewTextBoxColumn.ReadOnly = true;
      // 
      // tinyTimeBindingSource
      // 
      this.tinyTimeBindingSource.DataSource = typeof(TinyTiming.TinyTime);
      // 
      // buttonSignal
      // 
      this.buttonSignal.Location = new System.Drawing.Point(18, 208);
      this.buttonSignal.Name = "buttonSignal";
      this.buttonSignal.Size = new System.Drawing.Size(61, 55);
      this.buttonSignal.TabIndex = 7;
      this.buttonSignal.Text = "SIGNAL";
      this.buttonSignal.UseVisualStyleBackColor = true;
      this.buttonSignal.Click += new System.EventHandler(this.buttonSignal_Click);
      // 
      // buttonToFile
      // 
      this.buttonToFile.Location = new System.Drawing.Point(126, 240);
      this.buttonToFile.Name = "buttonToFile";
      this.buttonToFile.Size = new System.Drawing.Size(75, 23);
      this.buttonToFile.TabIndex = 8;
      this.buttonToFile.Text = "ToFile";
      this.buttonToFile.UseVisualStyleBackColor = true;
      this.buttonToFile.Click += new System.EventHandler(this.buttonToFile_Click);
      // 
      // cBcopyShortTime
      // 
      this.cBcopyShortTime.AutoSize = true;
      this.cBcopyShortTime.Location = new System.Drawing.Point(121, 217);
      this.cBcopyShortTime.Name = "cBcopyShortTime";
      this.cBcopyShortTime.Size = new System.Drawing.Size(113, 17);
      this.cBcopyShortTime.TabIndex = 9;
      this.cBcopyShortTime.Text = "Key out ShortTime";
      this.cBcopyShortTime.UseVisualStyleBackColor = true;
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(652, 431);
      this.Controls.Add(this.cBcopyShortTime);
      this.Controls.Add(this.buttonToFile);
      this.Controls.Add(this.buttonSignal);
      this.Controls.Add(this.dGVTimes);
      this.Controls.Add(this.labelStartValid);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.textBoxStartTime);
      this.Controls.Add(this.labelRunTime);
      this.Controls.Add(this.labelSysTime);
      this.Controls.Add(this.textBox1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "Form1";
      this.Text = "Form1";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
      ((System.ComponentModel.ISupportInitialize)(this.dGVTimes)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tinyTimeBindingSource)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.ComponentModel.BackgroundWorker bWPipeTIMclk;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Label labelSysTime;
    private System.Windows.Forms.Label labelRunTime;
    private System.Windows.Forms.Timer timerRefresh;
    private System.Windows.Forms.TextBox textBoxStartTime;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label labelStartValid;
    private System.Windows.Forms.DataGridView dGVTimes;
    private System.Windows.Forms.BindingSource tinyTimeBindingSource;
    private System.Windows.Forms.Button buttonSignal;
    private System.Windows.Forms.Button buttonToFile;
    private System.Windows.Forms.CheckBox cBcopyShortTime;
    private System.Windows.Forms.DataGridViewTextBoxColumn dGStartNumberDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn dGTimeDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn DGShortTime;
    private System.Windows.Forms.DataGridViewTextBoxColumn dGTimeSourceDataGridViewTextBoxColumn;
  }
}

