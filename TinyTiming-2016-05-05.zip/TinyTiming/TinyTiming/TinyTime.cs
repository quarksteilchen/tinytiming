﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.ComponentModel;
using System.Diagnostics;

namespace TinyTiming
{
  enum TimeSource { None=0, Manual=1, SerialPortPushButton=2 };
  enum TimeState {NONE,INVALID,ON,OFF};

  /// <summary>
  /// The Class which holds a single Time-Value
  /// </summary>
  class TinyTime
  {
    public TimeSpan internalTime;
    public TimeSource timeSource;
    public string startNumber;
    public TimeState timeState;

    // Constructor
    public TinyTime(TimeSpan time, TimeSource source, string startNumber)
    {
      this.internalTime = time;
      this.timeSource = source;
      this.startNumber = startNumber;
      this.timeState = TimeState.NONE;
    }

    // Copy Constructor
    public TinyTime(TinyTime toCopy)
    {
      this.internalTime = new TimeSpan(toCopy.internalTime.Hours,toCopy.internalTime.Minutes,toCopy.internalTime.Seconds,toCopy.internalTime.Milliseconds);
      this.timeSource = toCopy.timeSource;
      this.startNumber = toCopy.startNumber;
      this.timeState = toCopy.timeState;
    }

    // Parse-Method for 00:00:00,0
    public static TinyTime Parse(string raw,TimeSource ts=TimeSource.None,string stn="")
    {
      TimeSpan t = new TimeSpan(0, 0, 0, 0, 0);
      TinyTime temp = new TinyTime(TimeSpan.Zero, TimeSource.None, "");
      temp.timeState = TimeState.INVALID;
      // SPPB-EV:001 ON 00:00:00,000
      // SPPB-EV:001 OFF 00:00:00,000 

      if (raw.StartsWith("SPPB-"))
        temp.timeSource = TimeSource.SerialPortPushButton;

      string state = raw.Substring(12,3);
      if (state.StartsWith("ON"))
        temp.timeState = TimeState.ON;
      else if (state.StartsWith("OFF"))
        temp.timeState = TimeState.OFF;

      int timePos = raw.IndexOf(' ', 13, 3);

      if (timePos != -1)
      {
        // found possible beginning of time-string
        string possTime = raw.Substring(timePos, 13);
        string[] possTimeParts = possTime.Split(new char[] { ':', ',' });

        //Trace.WriteLine("Parse: possTimeParts " + " " + possTimeParts[0] + " " + possTimeParts[1] + " " + possTimeParts[2] + " " + possTimeParts[3]);

        if (possTimeParts.Length >= 4)
        {
          temp.internalTime = new TimeSpan(0,int.Parse(possTimeParts[0]), int.Parse(possTimeParts[1]), int.Parse(possTimeParts[2]), int.Parse(possTimeParts[3]));
        }
      }

      return temp;
    }


    // Overridden ToString for quick representation of the time value
    public override string ToString()
    {
      return this.internalTime.ToString(@"hh\:mm\:ss\,f");
      //return base.ToString();
    }

    // Access Methods (for the DataGridView)
    [DisplayName("St#")]
    public string DGStartNumber
    {
      get { return startNumber; }
      set { startNumber = value; }
    }
    [DisplayName("Source")]
    public string DGTimeSource
    {
      get { return timeSource.ToString(); }
    }
    [DisplayName("Time")]
    public string DGTime
    {
      get { return this.ToString(); }
      //set { internalTime = value; }
    }
    [DisplayName("Short")]
    public string DGShortTime
    {
      get { return this.ShortTime; }
    }

    public string ShortTime
    {
      get { 
        string tmp;
        tmp = internalTime.Minutes.ToString().PadLeft(2, '0');
        tmp += " ";
        tmp += internalTime.Seconds.ToString().PadLeft(2, '0');
        tmp += " ";
        tmp += internalTime.Milliseconds.ToString().Substring(0, 1);
        return tmp;
      }
    }
  }
}
